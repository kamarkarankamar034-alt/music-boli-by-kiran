MUSIC BOLI BY KIRAN — Hey Sweetie starter project (v1.1)

फोन: Vivo Y11 5G

अहिलेको सुविधाहरू:
- Microphone button बाट Android speech recognition चलाउने.
- बोलेको गीतको नाम YouTube search मा खोल्ने.
- Facebook र WhatsApp खोल्ने voice command को basic prototype.
- Purple/black theme.

महत्त्वपूर्ण सीमा:
- यो source project हो, तयार गरिएको वा device मा test गरिएको APK होइन.
- “Hey Sweetie” लाई सधैँ background मा सुनिरहने wake-word feature अझै समावेश छैन. अहिले voice control सुरु गर्न app भित्र microphone button थिच्नुपर्छ. सधैँ सुन्ने wake-word का लागि छुट्टै wake-word engine, battery/background restrictions र थप परीक्षण चाहिन्छ.
- Speech recognition फोनमा उपलब्ध speech service र language support मा निर्भर हुन्छ.
- Music खोज्दा YouTube मा खोल्छ; music file download गर्दैन.

APK बनाउन:
1. Computer मा Android Studio install गर्नुहोस्.
2. ZIP extract गरेर Android Studio बाट project folder खोल्नुहोस्.
3. Internet जोडेर Gradle sync पूरा हुन दिनुहोस्.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) छान्नुहोस्.
5. APK सामान्यतया app/build/outputs/apk/debug/app-debug.apk मा बन्नेछ.

यदि Android Studio ले compile SDK डाउनलोड गर्न भन्यो भने अनुमति दिनुहोस्. Build भएपछि Vivo मा APK transfer गरी install गर्नुहोस्; unknown-app install अनुमति मागिन सक्छ.
