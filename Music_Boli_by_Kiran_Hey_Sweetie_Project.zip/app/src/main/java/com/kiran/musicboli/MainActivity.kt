package com.kiran.musicboli

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var searchBox: EditText
    private lateinit var status: TextView
    private val voiceRequest = 42
    private val micPermissionRequest = 43

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(android.graphics.Color.rgb(17, 14, 35))
        }
        root.addView(TextView(this).apply {
            text = "🎵 Music Boli by Kiran"
            textSize = 27f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Welcome to Music Boli by Kiran ❤️\nVoice assistant: Sweetie"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, pad, 0, pad * 2)
        }, matchWrap())

        searchBox = EditText(this).apply {
            hint = "Geet ko naam lekhnuhos..."
            textSize = 17f
            singleLine = true
            setPadding(pad, pad, pad, pad)
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.LTGRAY)
            setBackgroundColor(android.graphics.Color.rgb(45, 39, 70))
        }
        root.addView(searchBox, matchWrap())
        root.addView(makeButton("🎙️  Hey Sweetie / Voice Control") { startVoiceSearch() }, matchWrap())
        root.addView(makeButton("🔎  YouTube ma geet khojnuhos") { searchMusic(searchBox.text.toString()) }, matchWrap())
        root.addView(makeButton("📘  Facebook kholnuhos") { openAppOrStore("com.facebook.katana") }, matchWrap())
        root.addView(makeButton("💬  WhatsApp kholnuhos") { openAppOrStore("com.whatsapp") }, matchWrap())
        status = TextView(this).apply {
            text = "Voice button thichera command bhannuhos.\nUdaharan: “play Arijit Singh song”"
            textSize = 14f
            setTextColor(android.graphics.Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad * 2, 0, 0)
        }
        root.addView(status, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = (10 * resources.displayMetrics.density).toInt() }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { action() }
    }

    private fun startVoiceSearch() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a song name or command")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            startActivityForResult(intent, voiceRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "Phone ma speech recognition service chahinchha.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Android callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val phrase = raw.trim()
        val lower = phrase.lowercase(Locale.ROOT)
        status.text = "Sweetie le sunyo: $phrase"
        when {
            lower.contains("facebook") -> openAppOrStore("com.facebook.katana")
            lower.contains("whatsapp") -> openAppOrStore("com.whatsapp")
            lower.contains("youtube") && (lower.contains("open") || lower.contains("khol")) ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            lower.startsWith("play ") -> searchMusic(phrase.substringAfter(" ", "").trim())
            lower.contains("song") || lower.contains("geet") || lower.contains("music") ->
                searchMusic(phrase.replace(Regex("(?i)^(hey sweetie|sweetie|search|find|play|geet|song|music)\\s*"), "").trim())
            else -> {
                searchBox.setText(phrase)
                status.text = "Command bujhna sakina. Geet ko naam YouTube ma khojdai..."
                searchMusic(phrase)
            }
        }
    }

    private fun searchMusic(queryRaw: String) {
        val query = queryRaw.trim()
        if (query.isEmpty()) {
            Toast.makeText(this, "Geet ko naam bhannuhos wa lekhhnuhos.", Toast.LENGTH_SHORT).show()
            return
        }
        searchBox.setText(query)
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")))
        } catch (_: Exception) {
            Toast.makeText(this, "YouTube/browser kholna sakiena.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAppOrStore(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else {
            val url = if (packageName == "com.whatsapp")
                "https://play.google.com/store/apps/details?id=com.whatsapp"
            else "https://play.google.com/store/apps/details?id=com.facebook.katana"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
}
